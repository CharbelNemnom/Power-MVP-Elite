﻿<#
 	.SYNOPSIS
	Advanced Hyper-V Replica Monitoring tool.

	.DESCRIPTION
	Advanced Hyper-V Replica Monitoring tool including email Alerts.

	.NOTES
	===========================================================================
	Created with : SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	File Name    : Get-HyperVReplicaHealth.ps1
	Author       : Charbel Nemnom
	Version      : 3.0
	Date created : 07.April.2015
	Last modified: 19.December.2016
	Requires     : PowerShell Version 4.0 or above
	OS           : Windows Server 2012, 2012 R2 or 2016 Hyper-V
	Module       : Hyper-V-PowerShell
	===========================================================================

	.LINK
	To provide feedback or for further assistance please visit:
	https://charbelnemnom.com

	.EXAMPLE
	.\Get-HyperVReplicaHealth.ps1 -PrimHyperV01 <PrimaryHost> -RepHyperV02 <ReplicaHost>
	This example will check first the HTTP connectivity to the Primary and Replica Hyper-V server,
    If both nodes are reachable, then it will look for primary Virtual Machines that are in Warning
    and Critical state and send you an alert.
    If any of the virtual machine is in Warning or Critical states,
    The replication will be resumed automatically without administrator intervention to restore the replication.
    
    .EXAMPLE
	.\Get-HyperVReplicaHealth.ps1 -PrimHyperV01 <PrimaryHost> -RepHyperV02 <ReplicaHost> -ExtHyperV03 <ExtendedReplicaHost>
    This example will check first the HTTP connectivity to the Primary, Replica and Extended Replica Hyper-V Hosts,
    If all nodes are reachable, then it will look for primary Virtual Machines that are in Warning
    and Critical state and send you an alert.
    If any of the virtual machine is in Warning or Critical states,
    The replication will be resumed automatically without administrator intervention to restore the replication.  
#>

[CmdletBinding()]
param (
	[Parameter(Position = 0, HelpMessage = 'Primary Hyper-V Server')]
	[Alias('PrimHV')]
	[String]$PrimHyperV01 = 'NINJA-HV01.VIRT.LAB',
	
	[Parameter(HelpMessage = 'Replica Hyper-V Server')]
	[Alias('RepHV')]
	[String]$RepHyperV02 = 'NINJA-HV02.VIRT.LAB',
	
	[Parameter(HelpMessage = 'Extended Hyper-V Replica Server')]
	[Alias('ExtHV')]
	[String]$ExtHyperV03
)

# Variables
$Filedate = Get-date
$report = $null
$FromEmail = "From@domain.com"
$ToEmail1 = "ToABC@domain.com"
$ToEmail2 = "ToXYZ@domain.com"
$email = new-object Net.Mail.MailMessage
$email.From = new-object Net.Mail.MailAddress($FromEmail)
$email.Priority = [System.Net.Mail.MailPriority]::High
$email.IsBodyHtml = $true
$email.Body = $report
$email.To.Add($ToEmail1)
$email.To.Add($ToEmail2)
$tableColor = "WhiteSmoke"
$errorColor = "Red"
$warningColor = "Yellow"
If ($ExtHyperV03)
{
	$HyperVHosts = "$PrimHyperV01", "$RepHyperV02", "$ExtHyperV03"
}
Else
{
	$HyperVHosts = "$PrimHyperV01", "$RepHyperV02"
}

# Establish Connection to SMTP server
$smtpServer = "smtp.domain.com"
$smtpCreds = new-object Net.NetworkCredential("username", "PassW0rd")
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$smtp.UseDefaultCredentials = $false
$smtp.Credentials = $smtpCreds

# HTML Style Definition
$report += "<!DOCTYPE html  PUBLIC`"-//W3C//DTD XHTML 1.0 Strict//EN`"  `"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd`">"
$report += "<html xmlns=`"http://www.w3.org/1999/xhtml`"><body>"
$report += "<style>"
$report += "TABLE{border-width:2px;border-style: solid;border-color: #C0C0C0 ;border-collapse: collapse;width: 100%}"
$report += "TH{border-width: 2px;padding: 0px;border-style: solid;border-color: #C0C0C0 ;text-align: left}"
$report += "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: #C0C0C0 ;text-align: left}"
$report += "TD{border-width: 2px;padding: 0px;border-style: solid;border-color: #C0C0C0 ;text-align: left}"
$report += "H1{font-family:Calibri;}"
$report += "H2{font-family:Calibri;}"
$report += "H3{font-family:Calibri;}"
$report += "Body{font-family:Calibri;}"
$report += "</style>"
$report += "<center><p style=""font-size:12px;color:#BDBDBD"">Get-HyperVReplicaHealth - ScriptVersion: 1.0 | Created By: Charbel Nemnom - Hyper-V MVP | Feedback: http://charbelnemnom.com</p></center>"

# Test Primary Hyper-V Host on Port 80, if not reachable then send email and terminate!
If ($PrimHyperV01)
{
	Write-Verbose "Checking $PrimHyperV01"
	$TestHVNode1HTTP = 1..3 | % { Test-NetConnection -ComputerName $PrimHyperV01 -Port 80 }
	If ($TestHVNode1HTTP.TcpTestSucceeded[2] -eq $false)
	{
		Write-Verbose "$PrimHyperV01 is Not Reachable"
		$email.Subject = "$PrimHyperV01 is not Reachable! $($filedate)"
		$report += "<B><p style=""color:#ff0000"">Error Hyper-V Replica HTTP Listener on $PrimHyperV01!</B></p> <br> <br>"
		Write-Verbose "Finalizing Report"
		$report += "</body></html>"
		Write-Verbose "Sending e-mail"
		$email.body = $report
		$smtp.Send($email)
		Break
	}
}

# Test Replica Hyper-V Host on Port 80, if not reachable then send email and terminate!
If ($RepHyperV02)
{
	Write-Verbose "Checking $RepHyperV02"
	$TestHVNode2HTTP = 1..3 | % { Test-NetConnection -ComputerName $RepHyperV02 -Port 80 }
	If ($TestHVNode2HTTP.TcpTestSucceeded[2] -eq $false)
	{
		Write-Verbose "$RepHyperV02 is Not Reachable"
		$email.Subject = "$RepHyperV02 is not Reachable! $($filedate)"
		$report += "<B><p style=""color:#ff0000"">Error Hyper-V Replica HTTP Listener on $RepHyperV02!</B></p> <br> <br>"
		Write-Verbose "Finalizing Report"
		$report += "</body></html>"
		Write-Verbose "Sending e-mail"
		$email.body = $report
		$smtp.Send($email)
		Break
	}
}

# Test Extended Hyper-V Replica Host on Port 80, if not reachable then send email and terminate!
If ($ExtHyperV03)
{
	Write-Verbose "Checking $ExtHyperV03"
	$TestHVNode3HTTP = 1..3 | % { Test-NetConnection -ComputerName $ExtHyperV03 -Port 80 }
	If ($TestHVNode3HTTP.TcpTestSucceeded[2] -eq $false)
	{
		Write-Verbose "$ExtHyperV03 is Not Reachable"
		$email.Subject = "$ExtHyperV03 is not Reachable! $($filedate)"
		$report += "<B><p style=""color:#ff0000"">Error Hyper-V Replica HTTP Listener on $ExtHyperV03!</B></p> <br> <br>"
		Write-Verbose "Finalizing Report"
		$report += "</body></html>"
		Write-Verbose "Sending e-mail"
		$email.body = $report
		$smtp.Send($email)
		Break
	}
}


# Check VM Replication in Warning State
If ($ExtHyperV03)
{
	$WarningVMs = Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationHealth -eq "Warning" } | select ReplicationHealth
}
Else
{
	$WarningVMs = Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationHealth -eq "Warning" } | select ReplicationHealth
}

# Check VM Replication in critical State
If ($ExtHyperV03)
{
	$CriticalVMs = Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationHealth -eq "Critical" } | select ReplicationHealth
}
Else
{
	$CriticalVMs = Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationHealth -eq "Critical" } | select ReplicationHealth
}

If ($WarningVMs -match "Warning")
{
	Write-Verbose "Warning Replica VMs Found"
	$email.Subject = "Virtual Machines Replication in Warning State! $($filedate)"
	$report += "<style>TH{background-color:Indigo}TR{background-color:$($warningColor)}</style>"
	# Get VM Replication Warning State (Primary, Replica and Extended Hyper-V Replica hosts)
	$report += "<B>Virtual Machine Warning Replication State!</B> <br> <br>"
	If ($ExtHyperV03)
	{
		# Resume VM Replication
        Write-Verbose "Resume VM Warning Replication..."    
        Get-VM -ComputerName $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationHealth -eq "Warning" -and $_.ReplicationState -ne "Replicating"} | Resume-VMReplication -Resynchronize 
        $report += "Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Warning" } | Get-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.ReplicationState }; Label = "Replication State" }, `
					  @{ Expression = { $_.ReplicationMode }; Label = "Replication Mode" }, `
					  @{ Expression = { $_.ReplicationHealth }; Label = "Replication Health" }, `
					  @{ Expression = { "{0:0.0}" -f ($_.FrequencySec / 60) }; Label = "Target Freq (min)" }, `
					  @{ Expression = { "{0:N0}" -f (($Filedate) - ($_.Lastreplicationtime)).TotalMinutes }; Label = "Delta (min)" }, `
					  @{ Expression = { $_.ComputerName }; Label = "Hyper-V Host" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br>"
	}
	Else
	{
		# Resume VM Replication
        Write-Verbose "Resume VM Warning Replication..."    
        Get-VM -ComputerName $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationHealth -eq "Warning" -and $_.ReplicationState -ne "Replicating"} | Resume-VMReplication -Resynchronize 
        # Get VM Replication Warning State (Primary, and Replica Hyper-V hosts)
		$report += "Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Warning" } | Get-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.ReplicationState }; Label = "Replication State" }, `
					  @{ Expression = { $_.ReplicationMode }; Label = "Replication Mode" }, `
					  @{ Expression = { $_.ReplicationHealth }; Label = "Replication Health" }, `
					  @{ Expression = { "{0:0.0}" -f ($_.FrequencySec / 60) }; Label = "Target Freq (min)" }, `
					  @{ Expression = { "{0:N0}" -f (($Filedate) - ($_.Lastreplicationtime)).TotalMinutes }; Label = "Delta (min)" }, `
					  @{ Expression = { $_.ComputerName }; Label = "Hyper-V Host" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br>"
	}
	
	# Measure VM Replication Warning State
	If ($ExtHyperV03)
	{
		$report += "Measure Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Warning" } | Measure-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.LReplTime }; Label = "Last Replication Time" }, `
					  @{ Expression = { $_.AvgLatency }; Label = "Avg Latency" }, `
					  @{ Expression = { $_.AvgReplSize }; Label = "Avg Repl Size" }, `
					  @{ Expression = { $_.MissedReplicationCount }; Label = "Missed Repl Count" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br> "
	}
	Else
	{
		$report += "Measure Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Warning" } | Measure-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.LReplTime }; Label = "Last Replication Time" }, `
					  @{ Expression = { $_.AvgLatency }; Label = "Avg Latency" }, `
					  @{ Expression = { $_.AvgReplSize }; Label = "Avg Repl Size" }, `
					  @{ Expression = { $_.MissedReplicationCount }; Label = "Missed Repl Count" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br> "
	}
	
	# Get Hyper-V Replica Warning Log
	$report += "<style>TH{background-color:$($warningColor)}TR{background-color:$($tableColor)}</style>"
	$report += "<B>Hyper-V Replica Warnings Event Log</B> <br> <br>"
	Foreach ($HyperVHost in $HyperVHosts)
	{
		$report += "Warnings $HyperVHost : <br>" + ((Get-WinEvent -ComputerName $HyperVHost -FilterHashTable @{ LogName = "Microsoft-Windows-Hyper-V-VMMS-Admin"; StartTime = ($Filedate).AddDays(-1); Level = 3 }) | `
		Select-Object @{ Expression = { $_.ID }; Label = "ID" },  `
					  @{ Expression = { $_.ProviderName }; Label = "Source" }, `
					  @{ Expression = { $_.Message }; Label = "Message" } `
		| ConvertTo-HTML -Fragment) `
		+ " <br>"
	}
}

If ($CriticalVMs -match "Critical")
{
	Write-Verbose "Critical Replica VMs Found"
	$email.Subject = "Virtual Machines Replication in Critical State! $($filedate)"
	$report += "<style>TH{background-color:Indigo}TR{background-color:$($errorColor)}</style>"
	# Get VM Replication Critical State (Primary, Replica and Extended Hyper-V Replica hosts)
	$report += "<B>Virtual Machine Critical Replication State!</B> <br> <br>"
	If ($ExtHyperV03)
	{
        # Resume VM Replication
        Write-Verbose "Resume VM Critical Replication..."
        Get-VM -ComputerName $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationHealth -eq "Critical" -and $_.ReplicationState -ne "Resynchronizing" } | Resume-VMReplication -Resynchronize 
		$report += "Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Critical" } | Get-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.ReplicationState }; Label = "Replication State" }, `
					  @{ Expression = { $_.ReplicationMode }; Label = "Replication Mode" }, `
					  @{ Expression = { $_.ReplicationHealth }; Label = "Replication Health" }, `
					  @{ Expression = { "{0:0.0}" -f ($_.FrequencySec / 60) }; Label = "Target Freq (min)" }, `
					  @{ Expression = { "{0:N0}" -f (($Filedate) - ($_.Lastreplicationtime)).TotalMinutes }; Label = "Delta (min)" }, `
					  @{ Expression = { $_.ComputerName }; Label = "Hyper-V Host" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br>"
	}
	Else
	{
		# Resume VM Replication
        Write-Verbose "Resume VM Critical Replication..."
        Get-VM -ComputerName $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationHealth -eq "Critical" -and $_.ReplicationState -ne "Resynchronizing" } | Resume-VMReplication -Resynchronize 
        # Get VM Replication Critical State (Primary, and Replica Hyper-V hosts)
		$report += "Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Critical" } | Get-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.ReplicationState }; Label = "Replication State" }, `
					  @{ Expression = { $_.ReplicationMode }; Label = "Replication Mode" }, `
					  @{ Expression = { $_.ReplicationHealth }; Label = "Replication Health" }, `
					  @{ Expression = { "{0:0.0}" -f ($_.FrequencySec / 60) }; Label = "Target Freq (min)" }, `
					  @{ Expression = { "{0:N0}" -f (($Filedate) - ($_.Lastreplicationtime)).TotalMinutes }; Label = "Delta (min)" }, `
					  @{ Expression = { $_.ComputerName }; Label = "Hyper-V Host" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br>"
	}
	
	# Measure VM Replication Critical State
	If ($ExtHyperV03)
	{
		$report += "Measure Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02, $ExtHyperV03 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Critical" } | Measure-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.LReplTime }; Label = "Last Replication Time" }, `
					  @{ Expression = { $_.AvgLatency }; Label = "Avg Latency" }, `
					  @{ Expression = { $_.AvgReplSize }; Label = "Avg Repl Size" }, `
					  @{ Expression = { $_.MissedReplicationCount }; Label = "Missed Repl Count" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br> "
	}
	Else
	{
		$report += "Measure Virtual Machine Replication Health: <br>" + ((Get-VM -computername $PrimHyperV01, $RepHyperV02 | ? { $_.ReplicationMode -eq "Primary" -and $_.ReplicationHealth -eq "Critical" } | Measure-VMReplication | `
		Select-Object @{ Expression = { $_.Name }; Label = "Name" }, `
					  @{ Expression = { $_.LReplTime }; Label = "Last Replication Time" }, `
					  @{ Expression = { $_.AvgLatency }; Label = "Avg Latency" }, `
					  @{ Expression = { $_.AvgReplSize }; Label = "Avg Repl Size" }, `
					  @{ Expression = { $_.MissedReplicationCount }; Label = "Missed Repl Count" } `
		| ConvertTo-HTML -Fragment) `
		| %{
			if ($_.Contains("<td>Replicating</td><td>Normal</td>")) { $_.Replace("<tr><td>", "<tr style=`"background-color:$($tableColor)`"><td>") }
			else { $_ }
		}) `
		+ " <br> "
		
	}
	# Get Hyper-V Replica Critical Log
	$report += "<style>TH{background-color:$($errorColor)}TR{background-color:$($tableColor)}</style>"
	$report += "<B>Hyper-V Replica Critical Event Log</B> <br> <br>"
	Foreach ($HyperVHost in $HyperVHosts)
	{
		$report += "Errors $HyperVHost : <br>" + ((Get-WinEvent -ComputerName $HyperVHost -FilterHashTable @{ LogName = "Microsoft-Windows-Hyper-V-VMMS-Admin"; StartTime = ($Filedate).AddDays(-1); Level = 2 }) | `
		Select-Object @{ Expression = { $_.ID }; Label = "ID" },  `
					  @{ Expression = { $_.ProviderName }; Label = "Source" }, `
					  @{ Expression = { $_.Message }; Label = "Message" } `
		| ConvertTo-HTML -Fragment) `
		+ " <br>"
	}
}

If ($WarningVMs -and $CriticalVMs)
{
	$email.Subject = "Virtual Machines Replication in Warning & Critical State! $($filedate)"
	Write-Verbose "Finalizing Report"
	$report += "</body></html>"
	Write-Verbose "Sending e-mail"
	$email.body = $report
	$smtp.Send($email)
}
Elseif ($WarningVMs -or $CriticalVMs)
{
	Write-Verbose "Finalizing Report"
	$report += "</body></html>"
	Write-Verbose "Sending e-mail"
	$email.body = $report
	$smtp.Send($email)
}